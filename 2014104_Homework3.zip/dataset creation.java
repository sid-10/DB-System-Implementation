import java.io.IOException;
import java.io.PrintWriter;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;


public class dataset {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//200000
		
		try{
		    PrintWriter writer = new PrintWriter("/home/sujeet/Documents/var3/actor.txt", "UTF-8");
		    writer.println("INSERT INTO Actor (a_id,name) VALUES");
		   for(int i=0;i<200000-1;i++)
			   {
			   Random rn = new Random();
				char[] chars = "abcdefghijklmnopqrstuvwxyz".toCharArray();
				StringBuilder sb = new StringBuilder();
				Random random = new Random();
				for (int j = 0; j < 15; j++) {
				    char c = chars[random.nextInt(chars.length)];
				    sb.append(c);
				}
				String output = sb.toString();
			   writer.println("("+(i+1)+", '"+output+"'),");
			   }
		   int i=199999;
		   Random rn = new Random();
			char[] chars = "abcdefghijklmnopqrstuvwxyz".toCharArray();
			StringBuilder sb = new StringBuilder();
			Random random = new Random();
			for (int j = 0; j < 15; j++) {
			    char c = chars[random.nextInt(chars.length)];
			    sb.append(c);
			}
			String output = sb.toString();
		   writer.println("("+(i+1)+", '"+output+"');");
		   
		    writer.close();
		} catch (IOException e) {
		   System.out.println(e);
		}
		
		try{
		    PrintWriter writer = new PrintWriter("/home/sujeet/Documents/var3/pcompany.txt", "UTF-8");
		    writer.println("INSERT INTO Production_Company (pc_id,name,address) VALUES ");
		   for(int i=0;i<50000-1;i++)
			   {
			  
				char[] chars = "abcdefghijklmnopqrstuvwxyz".toCharArray();
				StringBuilder sb = new StringBuilder();
				Random random = new Random();
				for (int j = 0; j < 10; j++) {
				    char c = chars[random.nextInt(chars.length)];
				    sb.append(c);
				}
				String output = sb.toString();
				StringBuilder sb1 = new StringBuilder();
				for (int j = 0; j < 30; j++) {
				    char c = chars[random.nextInt(chars.length)];
				    sb1.append(c);
				}
				String address = sb1.toString();
			   writer.println(" ("+(i+1)+", '"+output+"','"+address+"'),");
			   }
		   int i=49999;
		   char[] chars = "abcdefghijklmnopqrstuvwxyz".toCharArray();
			StringBuilder sb = new StringBuilder();
			Random random = new Random();
			for (int j = 0; j < 10; j++) {
			    char c = chars[random.nextInt(chars.length)];
			    sb.append(c);
			}
			String output = sb.toString();
			StringBuilder sb1 = new StringBuilder();
			for (int j = 0; j < 30; j++) {
			    char c = chars[random.nextInt(chars.length)];
			    sb1.append(c);
			}
			String address = sb1.toString();
		   writer.println(" ("+(i+1)+", '"+output+"','"+address+"');");
		    writer.close();
		} catch (IOException e) {
		   System.out.println(e);
		}
		
		try{
		    PrintWriter writer = new PrintWriter("/home/sujeet/Documents/var3/movie.txt", "UTF-8");
		    writer.println("INSERT INTO  Movie (m_id,name,year,imdb_score,production_company ) VALUES ");
		   for(int i=0;i< 1000000-1;i++)
			   {
			  
				char[] chars = "abcdefghijklmnopqrstuvwxyz".toCharArray();
				StringBuilder sb = new StringBuilder();
				Random random = new Random();
				for (int j = 0; j < 10; j++) {
				    char c = chars[random.nextInt(chars.length)];
				    sb.append(c);
				}
				String output = sb.toString();
				int year=1900 + (int)(Math.random() * ((2000 - 1900) + 1));
				if(i<900000)
				{
					 year=1990 + (int)(Math.random() * ((2000 - 1990) + 1));
				}
				else
				{
					 year=1900 + (int)(Math.random() * ((1990 - 1900) + 1));
				}
				float rand = new Random().nextFloat();
				float result;
				if(i<950000)
					{
				result = 1 + (rand * (2 - 1));
					}
				else
				{
					result = 3 + (rand * (5 - 3));
				}
				DecimalFormat df = new DecimalFormat("####0.00");
				String x=df.format(result);
				int pc_id=0;
				if(i<900000)
				{
				pc_id=1 + (int)(Math.random() * ((100 - 1) + 1));
				}
				else
				{
					 pc_id=101 + (int)(Math.random() * ((50000 - 101) + 1));
				}
			   writer.println(" ("+(i+1)+", '"+output+"',"+year+","+x+","+pc_id+"),");
			   }
		   int i=999999;
			char[] chars = "abcdefghijklmnopqrstuvwxyz".toCharArray();
			StringBuilder sb = new StringBuilder();
			Random random = new Random();
			for (int j = 0; j < 10; j++) {
			    char c = chars[random.nextInt(chars.length)];
			    sb.append(c);
			}
			String output = sb.toString();
			int year=1900 + (int)(Math.random() * ((2000 - 1900) + 1));
			float rand = new Random().nextFloat();
			float result;
			
				result = 3 + (rand * (5 - 3));
			
			DecimalFormat df = new DecimalFormat("####0.00");
			String x=df.format(result);

			
			int pc_id= 101 + (int)(Math.random() * ((50000 - 101) + 1));
		   writer.println(" ("+(i+1)+", '"+output+"',"+year+","+x+","+pc_id+");");
		    writer.close();
		} catch (IOException e) {
		   System.out.println(e);
		}
	
		
		try{
			 ArrayList<Integer> list = new ArrayList<Integer>();
		        for (int j=1; j<=200000; j++) {
		            list.add(new Integer(j));
		        }
			PrintWriter writer = new PrintWriter("/home/sujeet/Documents/var3/casting.txt", "UTF-8");
			   writer.println("INSERT INTO  Casting (m_id,a_id) VALUES");
			   
		   for(int i=0;i< 10-1;i++)
			   {
			   int a,b,c,d;
			   if(i<9)
				{
		        a=1 + (int)(Math.random() * ((100 - 1) + 1));
		         b=a;
		        while(b==a)
		        {
		        	 b=1 + (int)(Math.random() * ((100 - 1) + 1));
		        }
		         c=a;
		        while(c==b||c==a)
		        {
		        	 c=1 + (int)(Math.random() * ((100 - 1) + 1));
		        }
		        d=a;
		        while(d==a||d==b||d==c)
		        {
		        	 d=1 + (int)(Math.random() * ((100 - 1) + 1));
		        }
		       
				}
			   else
			   {
				    a=1 + (int)(Math.random() * ((200000 - 1) + 1));
			         b=a;
			        while(b==a)
			        {
			        	 b=1 + (int)(Math.random() * ((200000 - 1) + 1));
			        }
			        c=a;
			        while(c==b||c==a)
			        {
			        	 c=1 + (int)(Math.random() * ((200000 - 1) + 1));
			        }
			       d=a;
			        while(d==a||d==b||d==c)
			        {
			        	 d=1 + (int)(Math.random() * ((200000 - 1) + 1));
			        }
			         
			   }
		        if(a==b||b==c||c==d||b==d||a==d||a==c)
		        	 System.out.println("d"+d);
		    	//int id=1 + (int)(Math.random() * ((1000000 - 1) + 1));
				//int pc_id=1 + (int)(Math.random() * ((50000 - 1) + 1));
			   writer.println("("+(i+1)+","+list.get(a-1)+"),");
			   writer.println("("+(i+1)+","+list.get(b-1)+"),");
			   writer.println("("+(i+1)+","+list.get(c-1)+"),");
			   writer.println("("+(i+1)+","+list.get(d-1)+"),");
			   }
		   int i=10 + (int)(Math.random() * ((1000000 - 10) + 1));
		   int a=1 + (int)(Math.random() * ((200000 - 1) + 1));
	        int b=a;
	        while(b==a)
	        {
	        	 b=1 + (int)(Math.random() * ((200000 - 1) + 1));
	        }
	        int c=a;
	        while(c==b||c==a)
	        {
	        	 c=1 + (int)(Math.random() * ((200000 - 1) + 1));
	        }
	        int d=a;
	        while(d==a||d==b||d==c)
	        {
	        	 d=1 + (int)(Math.random() * ((200000 - 1) + 1));
	        }
	       
	       
	        if(a==b||b==c||c==d||b==d||a==d||a==c)
	        	 System.out.println("d"+d);
	    	//int id=1 + (int)(Math.random() * ((1000000 - 1) + 1));
			//int pc_id=1 + (int)(Math.random() * ((50000 - 1) + 1));
		   writer.println("("+(i+1)+","+list.get(a-1)+"),");
		   writer.println("("+(i+1)+","+list.get(b-1)+"),");
		   writer.println("("+(i+1)+","+list.get(c-1)+"),");
		   writer.println("("+(i+1)+","+list.get(d-1)+");");
		    writer.close();
		    
		    
		} catch (IOException e) {
		   System.out.println(e);
		}	
		
		
	
	}

}
