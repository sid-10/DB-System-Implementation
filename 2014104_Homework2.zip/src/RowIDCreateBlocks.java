

	import java.io.BufferedReader;
	import java.io.BufferedWriter;
	import java.io.FileReader;
	import java.io.FileWriter;
	import java.io.IOException;
	import java.io.PrintWriter;
	import java.util.ArrayList;
	import java.util.Arrays;
	import java.util.Collections;
	import java.util.HashMap;
	import java.util.List;
	import java.util.Map;
import java.util.Scanner;

	public class RowIDCreateBlocks {

		public static int bitArraySize = 2000000;
		public static int filerowids = 1000;
		
		
		public static void main(String[] args) throws IOException 
		{
			
			Map<Integer,List<Integer>> hm = new HashMap<Integer,List<Integer>>();
			Map<Integer,String> hmapmain = new HashMap<Integer,String>();
			Map<Integer,Integer> hmapcount = new HashMap<Integer,Integer>();
			 	
			BufferedReader br = null;
		    int readRecords = 0;
		    int break_flag = 0;
		    String readfile = "./dataset/dataset1.txt";
	    	while(readRecords<=bitArraySize)
		    {
	    		System.out.println("Read File : "+readfile);
	    		if(readfile.contains("dataset6667"))
	    			break_flag++;
	    		if(break_flag>0)
					break;
		    	try 
		    	{
		    		
		    		String sCurrentLine;
			        br = new BufferedReader(new FileReader(readfile));
		
			        int i=0;
			        while ((sCurrentLine = br.readLine()) != null) 
			        {
			            
			        	if(sCurrentLine.contains(".txt"))
			        	{
			        		readfile = sCurrentLine; 
			        		break;
			        	}    
			        	
			        	String[] arr = sCurrentLine.split(",");
			        	
			        	if(hm.containsKey(Integer.parseInt(arr[1])))
			        	{
			        		hm.get(Integer.parseInt(arr[1])).add(Integer.parseInt(arr[0]));
			        	}
			        	else
			        	{
			        		List<Integer> temp_arraylist = new ArrayList<Integer>();
			        		temp_arraylist.add(Integer.parseInt(arr[0]));
			        		hm.put(Integer.parseInt(arr[1]),temp_arraylist );
			        	}
			        	if(hmapcount.containsKey(Integer.parseInt(arr[1])))
			        	{
			        		int t_count  = hmapcount.get(Integer.parseInt(arr[1]));
			        		hmapcount.put(Integer.parseInt(arr[1]),t_count+1);
			        	}
			        	else
			        	{
			        		
			        		hmapcount.put(Integer.parseInt(arr[1]),1);
			        	}
	     	            readRecords++;
		
			            i++;
			        }
		
			    } catch (IOException e) {
			        e.printStackTrace();
			    } 
			    finally 
			    {
			        try {
			            if (br != null)br.close();
			        } catch (IOException ex) {
			            ex.printStackTrace();
			        }
			    }
		    	
		    }
	    	//System.out.println(Arrays.asList(hm));
	    	
	    	int file_ctr = 1;
	    	String writeAddress;
	    	int total_written_records = 0;
	    	for (Map.Entry<Integer, List<Integer>> entry : hm.entrySet()) 
	    	{
	    		
	    		writeAddress = "./rowIDData/rowidFile"+file_ctr+".txt";
	    		
	    		System.out.println("writeAddressM : "+writeAddress);
	    		int key = entry.getKey();
	    	    List<Integer> value = entry.getValue();
	    	    hmapmain.put(key,writeAddress);				//HERE Key is trans_amount and value is address of first file/block
	    	  
	    	    /*List<Integer> toWrite = new ArrayList<Integer>(Collections.nCopies(bitArraySize, 0));
	    	    for (int setOne = 0; setOne<value.size(); setOne++)
	    	    {
	    	    	toWrite.set(value.get(setOne)-1, 1);
	    	    }*/
	    	    int writtenRecords = 0;
	    	    
	    	    PrintWriter writer = new PrintWriter(new BufferedWriter(new FileWriter(writeAddress, true)));
		        
	    	    
	    	    	  
		    	    while(writtenRecords<value.size())
		    	    {
		    	    	//System.out.println("writing : "+toWrite.get(writtenRecords));
		    	    	if(writtenRecords%filerowids == 0 && writtenRecords>=1)
		    	    	{
		    	    		file_ctr++;	
		    	    		writeAddress = "./rowIDData/rowidFile"+file_ctr+".txt";
		    	    		writer.print("\n"+writeAddress);
		    	    		writer.close();
				    	    //System.out.println("writeAddress : "+writeAddress);
		    	    		writer = new PrintWriter(new BufferedWriter(new FileWriter(writeAddress, true)));
		    	    	}
		    	    	if(writtenRecords==value.size()-1)
		    	    		writer.print(value.get(writtenRecords));
		    	    	else
		    	    		writer.print(value.get(writtenRecords)+",");
		    	    	writtenRecords++;
			    	    
		    	    
		    	    }  
	    	    
	    	    
	    	    file_ctr++;
	    	    System.out.println("total_written_records : "+total_written_records+" :"+(bitArraySize-filerowids));
	    	    total_written_records+=writtenRecords;
	    	    if(total_written_records<bitArraySize-filerowids)								//TODO : CHANGE THIS BASED ON USER INPUT
	    	    {
	    	    	writer.print("\n./rowIDData/rowidFile"+file_ctr+".txt");
	    	    }writer.close();
	    	}
	    	    
	    	    

	    	
	    	while(true)
	    	{	
		    	Scanner sc = new Scanner(System.in);
		    	System.out.println("Enter number of 1s : ");
		    	int t = sc.nextInt();
		    	Integer[] randomVal=new Integer[bitArraySize]; 
				//sc.close();
		    	int blk = 0;
		    	int totalSum = 0;
				for(int i=0;i<t;i++)  
					randomVal[i]=1;                       
				for(int i=t;i<bitArraySize;i++)  
					randomVal[i]=0;
		    	
				Collections.shuffle(Arrays.asList(randomVal));
				
				FileReader fr = null;
				br = null;
				for (Map.Entry<Integer, String> entry : hmapmain.entrySet()) 
		    	{
					int m = 0;
					int count = 0;
					ArrayList<Integer> main = new ArrayList<Integer>();
					String FILENAME =entry.getValue();
					String j="";
					while(m<hmapcount.get(entry.getKey()))
					{
						
						try{
						
							
							
							fr = new FileReader(FILENAME);
							br = new BufferedReader(fr);
							blk++;
							String sCurrentLine;
							String hn="";
							br = new BufferedReader(new FileReader(FILENAME));
							
						
							sCurrentLine = br.readLine();
							String[] tempArr = sCurrentLine.split(",");
							
							for(int yz = 0; yz<tempArr.length; yz++)
							main.add(Integer.parseInt(tempArr[yz]));
							
							m=m+tempArr.length;
						
							j=br.readLine();
							
							
						}catch(Exception e)
						{
							//
						}
						FILENAME=j;
						System.out.println("inner Total Sum : "+totalSum+"\nBlocks Accessed : "+blk);
					}
					for(int xy = 0; xy<main.size(); xy++)
					{
						if(randomVal[main.get(xy)-1] == 1)
						{
							count++;
						}
					}
					totalSum += (entry.getKey()*count);
		    	}
				
				System.out.println("Total Sum : "+totalSum+"\nBlocks Accessed : "+blk);
	    	}

		}
			

}


