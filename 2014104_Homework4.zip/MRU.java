import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Scanner;

public class MRU {

	public static void main(String[] args) throws FileNotFoundException {
		ArrayList<Integer> buffers = new ArrayList<Integer>();
		int sizeBuffer = 0;
		
		HashMap<Integer, Integer> pageTable = new HashMap<Integer, Integer>();
		
		System.out.println("Enter no. of Buffers avaiable : ");
		Scanner sc = new Scanner(System.in);
		sizeBuffer = sc.nextInt();
		
		ArrayList<ArrayList<Integer>> dataset = new ArrayList<ArrayList<Integer>>();
		
		
	
		System.out.println("Enter no. of EMPOYEE records : ");
		int EMPRecords = sc.nextInt();
		System.out.println("Enter no. of EMPOYEE blocks : ");
		int EMPBlocks = sc.nextInt();
		
		int EMPBlockSize = EMPRecords/EMPBlocks;
		
		ArrayList<Integer> EMP = new ArrayList<Integer>();
		for(int i = 1; i <= EMPRecords; i++)
			EMP.add(i);
		
		
		System.out.println("Enter no. of Dept records : ");
		int DeptRecords = sc.nextInt();
		System.out.println("Enter no. of Dept blocks : ");
		int DeptBlocks = sc.nextInt();
		
		int DeptBlockSize = DeptRecords/DeptBlocks;
		
		ArrayList<Integer> Dept = new ArrayList<Integer>();
		for(int i = 1; i <= DeptRecords; i++)
			Dept.add(i);
		
		
		System.out.println("Enter no. of Proj records : ");
		int ProjRecords = sc.nextInt();
		System.out.println("Enter no. of Proj blocks : ");
		int ProjBlocks = sc.nextInt();
		
		int ProjBlockSize = ProjRecords/ProjBlocks;
		
		ArrayList<Integer> Proj = new ArrayList<Integer>();
		for(int i = 0; i < ProjRecords; i++)
			Proj.add(i);
		
	
		dataset.add(EMP);
		dataset.add(Dept);
		dataset.add(Proj);
	
		
		
/*		int firstEMPBlock = 1;
		int firstDeptBlock = EMPBlocks+1;
		int firstProjBlock = EMPBlocks+DeptBlocks+1;
		int curOuterBlock = 0;
		int curInnerBlock = 0;
		
		curOuterBlock = firstEMPBlock;
		curInnerBlock = firstDeptBlock;
		
		String ref_String = "";
		BufferedWriter bw = null;
		try 
		{
			//System.out.println("Hello");
			
			bw = new BufferedWriter(new FileWriter("referenceString1.txt",true));
			
			for(int i = 1; i <= EMPBlocks; i++)
			{	
				//System.out.println(curOuterBlock+" ");
				bw.write(curOuterBlock+" ");
				
				for(int j = 1; j <= DeptBlocks; j++)
				{
					bw.write(curInnerBlock+" ");
					
					for(int k = 1; k <= EMPBlockSize; k++)
					{
						bw.write(curOuterBlock+" ");
						
						for(int l = 1; l <= DeptBlockSize; l++)
						{
							bw.write(curInnerBlock+" ");	
						
						}	
					}
					curInnerBlock++;
				
				}
				curOuterBlock++;
				curInnerBlock=firstDeptBlock;
				bw.write("\n");
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		
		if(bw != null)
			try {
				bw.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		
		
		


		
		
		
		
		
		 curOuterBlock = 0;
		curInnerBlock = 0;
		
		curOuterBlock = firstDeptBlock;
		curInnerBlock = firstEMPBlock;
		
		
		
		try 
		{
			//System.out.println("Hello");
			
			bw = new BufferedWriter(new FileWriter("referenceString2.txt",true));
			
			for(int i = 1; i <= DeptBlocks; i++)
			{	
				//System.out.println(curOuterBlock+" ");
				bw.write(curOuterBlock+" ");
				
				for(int j = 1; j <= EMPBlocks; j++)
				{
					bw.write(curInnerBlock+" ");
					
					for(int k = 1; k <= DeptBlockSize; k++)
					{
						bw.write(curOuterBlock+" ");
						
						for(int l = 1; l <=EMPBlockSize; l++)
						{
							bw.write(curInnerBlock+" ");	
						
						}	
					}
					curInnerBlock++;
				
				}
				curOuterBlock++;
				curInnerBlock=firstEMPBlock;
				bw.write("\n");
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		
		if(bw != null)
			try {
				bw.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		
		
		

		
		 curOuterBlock = 0;
			curInnerBlock = 0;
			
			curOuterBlock = firstProjBlock;
			curInnerBlock = firstDeptBlock;
			
			
			try 
			{
				//System.out.println("Hello");
				
				bw = new BufferedWriter(new FileWriter("referenceString3.txt",true));
				
				for(int i = 1; i <= ProjBlocks; i++)
				{	
					//.out.println(curOuterBlock+" ");
					bw.write(curOuterBlock+" ");
					
					for(int j = 1; j <= DeptBlocks; j++)
					{
						bw.write(curInnerBlock+" ");
						
						for(int k = 1; k <= ProjBlockSize; k++)
						{
							bw.write(curOuterBlock+" ");
							
							for(int l = 1; l <=DeptBlockSize; l++)
							{
								bw.write(curInnerBlock+" ");	
							
							}	
						}
						curInnerBlock++;
					
					}
					curOuterBlock++;
					curInnerBlock=firstDeptBlock;
					bw.write("\n");
				}
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
				
			
			if(bw != null)
				try {
					bw.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
		
		
		
	
		
		
		
		
		
		
		 curOuterBlock = 0;
		curInnerBlock = 0;
		
		curOuterBlock = firstDeptBlock;
		curInnerBlock = firstProjBlock;
		
		
		
		try 
		{
			//System.out.println("Hello");
			
			bw = new BufferedWriter(new FileWriter("referenceString4.txt",true));
			
			for(int i = 1; i <= DeptBlocks; i++)
			{	
			//	System.out.println(curOuterBlock+" ");
				bw.write(curOuterBlock+" ");
				
				for(int j = 1; j <= ProjBlocks; j++)
				{
					bw.write(curInnerBlock+" ");
					
					for(int k = 1; k <= DeptBlockSize; k++)
					{
						bw.write(curOuterBlock+" ");
						
						for(int l = 1; l <=ProjBlockSize; l++)
						{
							bw.write(curInnerBlock+" ");	
						
						}	
					}
					curInnerBlock++;
				
				}
				curOuterBlock++;
				curInnerBlock=firstProjBlock;
				bw.write("\n");
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		
		if(bw != null)
			try {
				bw.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		
		
		
		*/
		
		int [] b={10, 20, 50, 75, 100, 200, 500, 1000, 1500, 2000, 2500 };
		for(int buffer_test_cases = 0; buffer_test_cases < 11; buffer_test_cases++)
		{
			System.out.println("No. of Buffers avaiable : "+b[buffer_test_cases]);
			//sizeBuffer = sc.nextInt();
			sizeBuffer=b[buffer_test_cases];
			int pageFaults = 0;
			int counter = 0;
			Scanner scanner = new Scanner(new File("referenceString1.txt"));
			ArrayList<Integer> buffer=new ArrayList<Integer>();
			ArrayList<Integer> array=new ArrayList<Integer>();
			
			int time=0;
			HashMap<Integer,Integer> map=new HashMap<Integer,Integer>();
			int fault=0;
			
				
				String line;
				
				while(scanner.hasNextInt())
				{
					time++;
				     int x=scanner.nextInt();
				    // System.out.println(x);
				     if(map.get(x)!=null)
				     {
				    	// System.out.println(map.get(x));
				    	int y=map.get(x);
				    	// System.out.println("y"+y);
				    	// System.out.println(buffer);
				    	int o=buffer.indexOf(x);
				    	// System.out.println("0"+o);
				    	int h=array.get(y);
				    	// System.out.println("h"+array.size());
				    	 array.remove(o);
				    	array.add(o,time);
				    	 
				     }
				     else
				     {
				    	 
				    	 fault++;
				    	 if(buffer.size()<sizeBuffer)
				    	 {
				    		 if(buffer.size()>0){
				    			
				    		 map.put(x,buffer.size());
					    	 buffer.add(buffer.size(),x);
					    	 //
					    	 array.add(buffer.indexOf(x),time);
					    	// System.out.println(array.size()+" "+buffer.indexOf(x)+" x"+x);
				    		 }
				    		 else
				    		 {
				    			 map.put(x,0);
						    	 buffer.add(x);
						    	
						    	 array.add(0,time);
						    	 
						    	 //System.out.println(array.size()+" "+buffer.indexOf(x)+" x"+x);
				    		 }
				    	 }
				    	 else
				    	 {
				    		 int max=Collections.max(array);
				    		// System.out.println(max+" "+array.size()+" x"+buffer.size());
				    		 int k=array.indexOf(max);
				    		 //buffer.indexOf(max);
				    		 //int r=map.get(max);
				    		 map.remove(buffer.get(k));
				    		 array.remove(k);
				    		 buffer.remove(k);
				    		 
				    		
				    		 
				    		 
				    		 map.put(x,buffer.size());
				    		 buffer.add(x);
					    	 array.add(buffer.indexOf(x),time);
				    		 
				    	 }
				    	 
				    	 
				    	
				    	 
				    	// array.add()
				    	 
				     }
				     
				     
				     
				}
			
			
			//System.out.println(fault);
			
			
			
			System.out.println("\nQ1 : Page Faults : "+fault);
			
			
			
			
			
			
			pageFaults = 0;
			counter = 0;
			scanner = new Scanner(new File("referenceString2.txt"));
			buffer=new ArrayList<Integer>();
		 array=new ArrayList<Integer>();
			
			 time=0;
			 map=new HashMap<Integer,Integer>();
			 fault=0;
			
				
				while(scanner.hasNextInt())
				{
					time++;
				     int x=scanner.nextInt();
				    // System.out.println(x);
				     if(map.get(x)!=null)
				     {
				    	// System.out.println(map.get(x));
				    	int y=map.get(x);
				    	// System.out.println("y"+y);
				    	// System.out.println(buffer);
				    	int o=buffer.indexOf(x);
				    	// System.out.println("0"+o);
				    	int h=array.get(y);
				    	// System.out.println("h"+array.size());
				    	 array.remove(o);
				    	array.add(o,time);
				    	 
				     }
				     else
				     {
				    	 
				    	 fault++;
				    	 if(buffer.size()<sizeBuffer)
				    	 {
				    		 if(buffer.size()>0){
				    			
				    		 map.put(x,buffer.size());
					    	 buffer.add(buffer.size(),x);
					    	 //
					    	 array.add(buffer.indexOf(x),time);
					    	// System.out.println(array.size()+" "+buffer.indexOf(x)+" x"+x);
				    		 }
				    		 else
				    		 {
				    			 map.put(x,0);
						    	 buffer.add(x);
						    	
						    	 array.add(0,time);
						    	 
						    	 //System.out.println(array.size()+" "+buffer.indexOf(x)+" x"+x);
				    		 }
				    	 }
				    	 else
				    	 {
				    		 int max=Collections.max(array);
				    		// System.out.println(max+" "+array.size()+" x"+buffer.size());
				    		 int k=array.indexOf(max);
				    		 //buffer.indexOf(max);
				    		 //int r=map.get(max);
				    		 map.remove(buffer.get(k));
				    		 array.remove(k);
				    		 buffer.remove(k);
				    		 
				    		
				    		 
				    		 
				    		 map.put(x,buffer.size());
				    		 buffer.add(x);
					    	 array.add(buffer.indexOf(x),time);
				    		 
				    	 }
				    	 
				    	 
				    	
				    	 
				    	// array.add()
				    	 
				     }
				     
				     
				     
				}
			
			
			//System.out.println(fault);
			
			System.out.println("\nQ2 : Page Faults : "+fault);
			
			
			
			
			
			
			
			
			
			
			pageFaults = 0;
			counter = 0;
			scanner = new Scanner(new File("referenceString3.txt"));
			buffer=new ArrayList<Integer>();
			 array=new ArrayList<Integer>();
				
				 time=0;
				 map=new HashMap<Integer,Integer>();
				 fault=0;
				
					
					while(scanner.hasNextInt())
					{
						time++;
					     int x=scanner.nextInt();
					    // System.out.println(x);
					     if(map.get(x)!=null)
					     {
					    	// System.out.println(map.get(x));
					    	int y=map.get(x);
					    	// System.out.println("y"+y);
					    	// System.out.println(buffer);
					    	int o=buffer.indexOf(x);
					    	// System.out.println("0"+o);
					    	int h=array.get(y);
					    	// System.out.println("h"+array.size());
					    	 array.remove(o);
					    	array.add(o,time);
					    	 
					     }
					     else
					     {
					    	 
					    	 fault++;
					    	 if(buffer.size()<sizeBuffer)
					    	 {
					    		 if(buffer.size()>0){
					    			
					    		 map.put(x,buffer.size());
						    	 buffer.add(buffer.size(),x);
						    	 //
						    	 array.add(buffer.indexOf(x),time);
						    	// System.out.println(array.size()+" "+buffer.indexOf(x)+" x"+x);
					    		 }
					    		 else
					    		 {
					    			 map.put(x,0);
							    	 buffer.add(x);
							    	
							    	 array.add(0,time);
							    	 
							    	 //System.out.println(array.size()+" "+buffer.indexOf(x)+" x"+x);
					    		 }
					    	 }
					    	 else
					    	 {
					    		 int max=Collections.max(array);
					    		// System.out.println(max+" "+array.size()+" x"+buffer.size());
					    		 int k=array.indexOf(max);
					    		 //buffer.indexOf(max);
					    		 //int r=map.get(max);
					    		 map.remove(buffer.get(k));
					    		 array.remove(k);
					    		 buffer.remove(k);
					    		 
					    		
					    		 
					    		 
					    		 map.put(x,buffer.size());
					    		 buffer.add(x);
						    	 array.add(buffer.indexOf(x),time);
					    		 
					    	 }
					    	 
					    	 
					    	
					    	 
					    	// array.add()
					    	 
					     }
					     
					     
					     
					}
				
			
			System.out.println("\nQ3 : Page Faults : "+fault);
		
			
			
			
			
			
			
			
			
			
			
			
			
			pageFaults = 0;
			counter = 0;
			scanner = new Scanner(new File("referenceString4.txt"));
			buffer=new ArrayList<Integer>();
			 array=new ArrayList<Integer>();
				
				 time=0;
				 map=new HashMap<Integer,Integer>();
				 fault=0;
				
					
					while(scanner.hasNextInt())
					{
						time++;
					     int x=scanner.nextInt();
					    // System.out.println(x);
					     if(map.get(x)!=null)
					     {
					    	// System.out.println(map.get(x));
					    	int y=map.get(x);
					    	// System.out.println("y"+y);
					    	// System.out.println(buffer);
					    	int o=buffer.indexOf(x);
					    	// System.out.println("0"+o);
					    	int h=array.get(y);
					    	// System.out.println("h"+array.size());
					    	 array.remove(o);
					    	array.add(o,time);
					    	 
					     }
					     else
					     {
					    	 
					    	 fault++;
					    	 if(buffer.size()<sizeBuffer)
					    	 {
					    		 if(buffer.size()>0){
					    			
					    		 map.put(x,buffer.size());
						    	 buffer.add(buffer.size(),x);
						    	 //
						    	 array.add(buffer.indexOf(x),time);
						    	// System.out.println(array.size()+" "+buffer.indexOf(x)+" x"+x);
					    		 }
					    		 else
					    		 {
					    			 map.put(x,0);
							    	 buffer.add(x);
							    	
							    	 array.add(0,time);
							    	 
							    	 //System.out.println(array.size()+" "+buffer.indexOf(x)+" x"+x);
					    		 }
					    	 }
					    	 else
					    	 {
					    		 int max=Collections.max(array);
					    		// System.out.println(max+" "+array.size()+" x"+buffer.size());
					    		 int k=array.indexOf(max);
					    		 //buffer.indexOf(max);
					    		 //int r=map.get(max);
					    		 map.remove(buffer.get(k));
					    		 array.remove(k);
					    		 buffer.remove(k);
					    		 
					    		
					    		 
					    		 
					    		 map.put(x,buffer.size());
					    		 buffer.add(x);
						    	 array.add(buffer.indexOf(x),time);
					    		 
					    	 }
					    	 
					    	 
					    	
					    	 
					    	// array.add()
					    	 
					     }
					     
					     
					     
					}
				
			
		
		
			
			
			
			System.out.println("\nQ4 : Page Faults : "+fault);
			
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}