import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class BitArray {

	public static int bitArraySize = 2000000;					//TODO:  CHANGE THIS
	public static int filebits = 32000;							//TODO:  CHANGE THIS
	
	
	public static void main(String[] args) throws IOException 
	{
		
		Map<Integer,List<Integer>> hm = new HashMap<Integer,List<Integer>>();
		Map<Integer,String> hmapmain = new HashMap<Integer,String>();
		 	
		BufferedReader br = null;
	    int readRecords = 0;
	    int break_flag = 0;
	    String readfile = "./dataset/dataset1.txt";
    	while(readRecords<=bitArraySize)
	    {
    		System.out.println("Read File : "+readfile);
    		if(readfile.contains("dataset6667"))				//TODO:  CHANGE THIS
    			break_flag++;
    		if(break_flag>0)
				break;
	    	try 
	    	{
	    		
	    		String sCurrentLine;
		        br = new BufferedReader(new FileReader(readfile));
	
		        int i=0;
		        while ((sCurrentLine = br.readLine()) != null) 
		        {
		            
		        	if(sCurrentLine.contains(".txt"))
		        	{
		        		readfile = sCurrentLine; 
		        		break;
		        	}    
		        	
		        	String[] arr = sCurrentLine.split(",");
		        	
		        	if(hm.containsKey(Integer.parseInt(arr[1])))
		        	{
		        		hm.get(Integer.parseInt(arr[1])).add(Integer.parseInt(arr[0]));
		        	}
		        	else
		        	{
		        		List<Integer> temp_arraylist = new ArrayList<Integer>();
		        		temp_arraylist.add(Integer.parseInt(arr[0]));
		        		hm.put(Integer.parseInt(arr[1]),temp_arraylist );
		        	}
     	            readRecords++;
	
		            i++;
		        }
	
		    } catch (IOException e) {
		        e.printStackTrace();
		    } 
		    finally 
		    {
		        try {
		            if (br != null)br.close();
		        } catch (IOException ex) {
		            ex.printStackTrace();
		        }
		    }
	    	
	    }
    	//System.out.println(Arrays.asList(hm));
    	
    	int file_ctr = 1;
    	String writeAddress;
    	for (Map.Entry<Integer, List<Integer>> entry : hm.entrySet()) 
    	{
    		
    		writeAddress = "./bitArrayData/bitArrFile"+file_ctr+".txt";
    		
    		System.out.println("writeAddressM : "+writeAddress);
    		int key = entry.getKey();
    	    List<Integer> value = entry.getValue();
    	    hmapmain.put(key,writeAddress);				//HERE Key is trans_amount and value is address of first file/block
    	  
    	    List<Integer> toWrite = new ArrayList<Integer>(Collections.nCopies(bitArraySize, 0));
    	    for (int setOne = 0; setOne<value.size(); setOne++)
    	    {
    	    	toWrite.set(value.get(setOne)-1, 1);
    	    }
    	    int writtenRecords = 0;
    	    
    	    PrintWriter writer = new PrintWriter(new BufferedWriter(new FileWriter(writeAddress, true)));
	        
    	    
    	    	  
	    	    while(writtenRecords<toWrite.size())
	    	    {
	    	    	//System.out.println("writing : "+toWrite.get(writtenRecords));
	    	    	if(writtenRecords%filebits == 0 && writtenRecords>=1)
	    	    	{
	    	    		file_ctr++;	
	    	    		writeAddress = "./bitArrayData/bitArrFile"+file_ctr+".txt";
	    	    		writer.print("\n"+writeAddress);
	    	    		writer.close();
			    	    //System.out.println("writeAddress : "+writeAddress);
	    	    		writer = new PrintWriter(new BufferedWriter(new FileWriter(writeAddress, true)));
	    	    	}
	    	    	writer.print(toWrite.get(writtenRecords));
		    	    writtenRecords++;
		    	    
	    	    
	    	    }  
    	    
    	    
    	    file_ctr++;
    	    if(!readfile.contains("dataset6667"))								//TODO : CHANGE THIS BASED ON USER INPUT
    	    	writer.print("\n./bitArrayData/bitArrFile"+file_ctr+".txt");
    	    writer.close();
    	}
    	    
    	   
    	
    	while(true)
    	{	
	    	Scanner sc = new Scanner(System.in);
	    	System.out.println("Enter number of 1s : ");
	    	int t = sc.nextInt();
	    	Integer[] randomVal=new Integer[bitArraySize]; 
			sc.close();
	    	int blk = 0;
	    	int totalSum = 0;
			for(int i=0;i<t;i++)  
				randomVal[i]=1;                       
			for(int i=t;i<bitArraySize;i++)  
				randomVal[i]=0;
	    	
			Collections.shuffle(Arrays.asList(randomVal));
			
			FileReader fr = null;
			br = null;
			for (Map.Entry<Integer, String> entry : hmapmain.entrySet()) 
	    	{
				int m = 0;
				int count = 0;
				String main = "";
				String FILENAME =entry.getValue();
				String j="";
				while(m<bitArraySize)
				{
					
					try{
					
					fr = new FileReader(FILENAME);
					br = new BufferedReader(fr);
					blk++;
					String sCurrentLine;
					String hn="";
					br = new BufferedReader(new FileReader(FILENAME));
					
				
					sCurrentLine = br.readLine();
					main=main+sCurrentLine;
					m=m+sCurrentLine.length();
				
					j=br.readLine();
					
					}catch(Exception e)
					{
						//
					}
					FILENAME=j;
				
				}
				for(int xy = 0; xy<randomVal.length; xy++)
				{
					if(randomVal[xy] == 1 && main.charAt(xy)=='1')
					{
						count++;
					}
				}
				totalSum += (entry.getKey()*count);
	    	}
			
			System.out.println("Total Sum : "+totalSum+"\nBlocks Accessed : "+blk);
    	}
    	
	}
		

}


