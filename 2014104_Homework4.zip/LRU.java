import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class LRU {

	public static void main(String[] args) throws FileNotFoundException {
		ArrayList<Integer> buffers = new ArrayList<Integer>();
		int sizeBuffer = 0;
		
		HashMap<Integer, Integer> pageTable = new HashMap<Integer, Integer>();
		
		System.out.println("Enter no. of Buffers avaiable : ");
		Scanner sc = new Scanner(System.in);
		sizeBuffer = sc.nextInt();
		
		ArrayList<ArrayList<Integer>> dataset = new ArrayList<ArrayList<Integer>>();
		
		
	
		System.out.println("Enter no. of EMPOYEE records : ");
		int EMPRecords = sc.nextInt();
		System.out.println("Enter no. of EMPOYEE blocks : ");
		int EMPBlocks = sc.nextInt();
		
		int EMPBlockSize = EMPRecords/EMPBlocks;
		
		ArrayList<Integer> EMP = new ArrayList<Integer>();
		for(int i = 1; i <= EMPRecords; i++)
			EMP.add(i);
		
		
		System.out.println("Enter no. of Dept records : ");
		int DeptRecords = sc.nextInt();
		System.out.println("Enter no. of Dept blocks : ");
		int DeptBlocks = sc.nextInt();
		
		int DeptBlockSize = DeptRecords/DeptBlocks;
		
		ArrayList<Integer> Dept = new ArrayList<Integer>();
		for(int i = 1; i <= DeptRecords; i++)
			Dept.add(i);
		
		
		System.out.println("Enter no. of Proj records : ");
		int ProjRecords = sc.nextInt();
		System.out.println("Enter no. of Proj blocks : ");
		int ProjBlocks = sc.nextInt();
		
		int ProjBlockSize = ProjRecords/ProjBlocks;
		
		ArrayList<Integer> Proj = new ArrayList<Integer>();
		for(int i = 0; i < ProjRecords; i++)
			Proj.add(i);
		
	
		dataset.add(EMP);
		dataset.add(Dept);
		dataset.add(Proj);
	
		
		
/*		int firstEMPBlock = 1;
		int firstDeptBlock = EMPBlocks+1;
		int firstProjBlock = EMPBlocks+DeptBlocks+1;
		int curOuterBlock = 0;
		int curInnerBlock = 0;
		
		curOuterBlock = firstEMPBlock;
		curInnerBlock = firstDeptBlock;
		
		String ref_String = "";
		BufferedWriter bw = null;
		try 
		{
			//System.out.println("Hello");
			
			bw = new BufferedWriter(new FileWriter("referenceString1.txt",true));
			
			for(int i = 1; i <= EMPBlocks; i++)
			{	
				//System.out.println(curOuterBlock+" ");
				bw.write(curOuterBlock+" ");
				
				for(int j = 1; j <= DeptBlocks; j++)
				{
					bw.write(curInnerBlock+" ");
					
					for(int k = 1; k <= EMPBlockSize; k++)
					{
						bw.write(curOuterBlock+" ");
						
						for(int l = 1; l <= DeptBlockSize; l++)
						{
							bw.write(curInnerBlock+" ");	
						
						}	
					}
					curInnerBlock++;
				
				}
				curOuterBlock++;
				curInnerBlock=firstDeptBlock;
				bw.write("\n");
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		
		if(bw != null)
			try {
				bw.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		
		
		


		
		
		
		
		
		 curOuterBlock = 0;
		curInnerBlock = 0;
		
		curOuterBlock = firstDeptBlock;
		curInnerBlock = firstEMPBlock;
		
		
		
		try 
		{
			//System.out.println("Hello");
			
			bw = new BufferedWriter(new FileWriter("referenceString2.txt",true));
			
			for(int i = 1; i <= DeptBlocks; i++)
			{	
				//System.out.println(curOuterBlock+" ");
				bw.write(curOuterBlock+" ");
				
				for(int j = 1; j <= EMPBlocks; j++)
				{
					bw.write(curInnerBlock+" ");
					
					for(int k = 1; k <= DeptBlockSize; k++)
					{
						bw.write(curOuterBlock+" ");
						
						for(int l = 1; l <=EMPBlockSize; l++)
						{
							bw.write(curInnerBlock+" ");	
						
						}	
					}
					curInnerBlock++;
				
				}
				curOuterBlock++;
				curInnerBlock=firstEMPBlock;
				bw.write("\n");
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		
		if(bw != null)
			try {
				bw.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		
		
		

		
		 curOuterBlock = 0;
			curInnerBlock = 0;
			
			curOuterBlock = firstProjBlock;
			curInnerBlock = firstDeptBlock;
			
			
			try 
			{
				//System.out.println("Hello");
				
				bw = new BufferedWriter(new FileWriter("referenceString3.txt",true));
				
				for(int i = 1; i <= ProjBlocks; i++)
				{	
					//.out.println(curOuterBlock+" ");
					bw.write(curOuterBlock+" ");
					
					for(int j = 1; j <= DeptBlocks; j++)
					{
						bw.write(curInnerBlock+" ");
						
						for(int k = 1; k <= ProjBlockSize; k++)
						{
							bw.write(curOuterBlock+" ");
							
							for(int l = 1; l <=DeptBlockSize; l++)
							{
								bw.write(curInnerBlock+" ");	
							
							}	
						}
						curInnerBlock++;
					
					}
					curOuterBlock++;
					curInnerBlock=firstDeptBlock;
					bw.write("\n");
				}
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
				
			
			if(bw != null)
				try {
					bw.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
		
		
		
	
		
		
		
		
		
		
		 curOuterBlock = 0;
		curInnerBlock = 0;
		
		curOuterBlock = firstDeptBlock;
		curInnerBlock = firstProjBlock;
		
		
		
		try 
		{
			//System.out.println("Hello");
			
			bw = new BufferedWriter(new FileWriter("referenceString4.txt",true));
			
			for(int i = 1; i <= DeptBlocks; i++)
			{	
			//	System.out.println(curOuterBlock+" ");
				bw.write(curOuterBlock+" ");
				
				for(int j = 1; j <= ProjBlocks; j++)
				{
					bw.write(curInnerBlock+" ");
					
					for(int k = 1; k <= DeptBlockSize; k++)
					{
						bw.write(curOuterBlock+" ");
						
						for(int l = 1; l <=ProjBlockSize; l++)
						{
							bw.write(curInnerBlock+" ");	
						
						}	
					}
					curInnerBlock++;
				
				}
				curOuterBlock++;
				curInnerBlock=firstProjBlock;
				bw.write("\n");
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		
		if(bw != null)
			try {
				bw.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		
		
		
		*/
		
		
		for(int buffer_test_cases = 0; buffer_test_cases < 11; buffer_test_cases++)
		{
			System.out.println("Enter no. of Buffers avaiable : ");
			sizeBuffer = sc.nextInt();
			int pageFaults = 0;
			int counter = 0;
			Scanner scanner = new Scanner(new File("referenceString1.txt"));
			while(scanner.hasNextInt())
			{
				if(counter%1000000 == 0)
					System.out.println("LOL : "+ counter);
				
				counter++;
				int page = scanner.nextInt();
				//System.out.println("Page to Insert : "+page);
				
				if(pageTable.containsKey(page))
				{
					
	/*				System.out.println("C Buffers : "+buffers);
					System.out.println("C Page Table : "+pageTable);
					System.out.println("C Page Table keys : "+pageTable.keySet());
	*/				
					
					if(buffers.indexOf(page)==buffers.size()-1)
					{
						//System.out.println("Do noin..");	
					}
					else
					{
						ArrayList<Integer> reducePageTable = new ArrayList<>();
						for(int x = 0; x < buffers.size(); x++)
						{
							if(buffers.indexOf(page)<x)
								reducePageTable.add(buffers.get(x));
						}
						
						buffers.remove(new Integer(page));
						int currentBufferSize = buffers.size();
						buffers.add(currentBufferSize, page);
						for (Integer key : pageTable.keySet()) 
						{
							if(reducePageTable.contains(key))
							{	
								//System.out.println("Reducing key : "+key);
								pageTable.put(key, pageTable.get(key) - 1);
							}
						}
						pageTable.put(page, currentBufferSize);
						
					/*	System.out.println("C Updated Buffers : "+buffers);
						System.out.println("C Updated Page Table : "+pageTable);
						System.out.println("C Updated Page Table keys : "+pageTable.keySet());
					*/
					}
				}
				else
				{
				/*	System.out.println("Page Table doesnt have pg");
				*/
					pageFaults++;
					
					int currentBufferSize = buffers.size();
					if(currentBufferSize<sizeBuffer)
					{
						buffers.add(currentBufferSize, page);
						pageTable.put(page, currentBufferSize);
					}
					else
					{
						int pageToRemove = buffers.get(0);
						buffers.remove(0);
						pageTable.remove(pageToRemove);
						for (Integer key : pageTable.keySet()) {
							pageTable.put(key, pageTable.get(key) - 1);
						}
						currentBufferSize = buffers.size();
						buffers.add(currentBufferSize, page);
						pageTable.put(page, currentBufferSize);
					}
				/*	System.out.println("Updated Buffers : "+buffers);
					System.out.println("Updated Page Table : "+pageTable);
					System.out.println("Updated Page Table keys : "+pageTable.keySet());
				*/	
				}
			}
			
			buffers = new ArrayList<Integer>();
			pageTable = new HashMap<Integer, Integer>();
			
			System.out.println("\nQ1 : Page Faults : "+pageFaults);
			
			
			
			
			
			
			pageFaults = 0;
			counter = 0;
			scanner = new Scanner(new File("referenceString2.txt"));
			while(scanner.hasNextInt())
			{
				
				counter++;
				int page = scanner.nextInt();
				//System.out.println("Page to Insert : "+page);
				
				if(pageTable.containsKey(page))
				{
					
	/*				System.out.println("C Buffers : "+buffers);
					System.out.println("C Page Table : "+pageTable);
					System.out.println("C Page Table keys : "+pageTable.keySet());
	*/				
					
					if(buffers.indexOf(page)==buffers.size()-1)
					{
						//System.out.println("Do noin..");	
					}
					else
					{
						ArrayList<Integer> reducePageTable = new ArrayList<>();
						for(int x = 0; x < buffers.size(); x++)
						{
							if(buffers.indexOf(page)<x)
								reducePageTable.add(buffers.get(x));
						}
						
						buffers.remove(new Integer(page));
						int currentBufferSize = buffers.size();
						buffers.add(currentBufferSize, page);
						for (Integer key : pageTable.keySet()) 
						{
							if(reducePageTable.contains(key))
							{	
								//System.out.println("Reducing key : "+key);
								pageTable.put(key, pageTable.get(key) - 1);
							}
						}
						pageTable.put(page, currentBufferSize);
						
					/*	System.out.println("C Updated Buffers : "+buffers);
						System.out.println("C Updated Page Table : "+pageTable);
						System.out.println("C Updated Page Table keys : "+pageTable.keySet());
					*/
					}
				}
				else
				{
				/*	System.out.println("Page Table doesnt have pg");
				*/
					pageFaults++;
					
					int currentBufferSize = buffers.size();
					if(currentBufferSize<sizeBuffer)
					{
						buffers.add(currentBufferSize, page);
						pageTable.put(page, currentBufferSize);
					}
					else
					{
						int pageToRemove = buffers.get(0);
						buffers.remove(0);
						pageTable.remove(pageToRemove);
						for (Integer key : pageTable.keySet()) {
							pageTable.put(key, pageTable.get(key) - 1);
						}
						currentBufferSize = buffers.size();
						buffers.add(currentBufferSize, page);
						pageTable.put(page, currentBufferSize);
					}
				/*	System.out.println("Updated Buffers : "+buffers);
					System.out.println("Updated Page Table : "+pageTable);
					System.out.println("Updated Page Table keys : "+pageTable.keySet());
				*/	
				}
			}
			
			buffers = new ArrayList<Integer>();
			pageTable = new HashMap<Integer, Integer>();
			
			System.out.println("\nQ2 : Page Faults : "+pageFaults);
			
			
			
			
			
			
			
			
			
			
			pageFaults = 0;
			counter = 0;
			scanner = new Scanner(new File("referenceString3.txt"));
			while(scanner.hasNextInt())
			{
				
				counter++;
				int page = scanner.nextInt();
				//System.out.println("Page to Insert : "+page);
				
				if(pageTable.containsKey(page))
				{
					
	/*				System.out.println("C Buffers : "+buffers);
					System.out.println("C Page Table : "+pageTable);
					System.out.println("C Page Table keys : "+pageTable.keySet());
	*/				
					
					if(buffers.indexOf(page)==buffers.size()-1)
					{
						//System.out.println("Do noin..");	
					}
					else
					{
						ArrayList<Integer> reducePageTable = new ArrayList<>();
						for(int x = 0; x < buffers.size(); x++)
						{
							if(buffers.indexOf(page)<x)
								reducePageTable.add(buffers.get(x));
						}
						
						buffers.remove(new Integer(page));
						int currentBufferSize = buffers.size();
						buffers.add(currentBufferSize, page);
						for (Integer key : pageTable.keySet()) 
						{
							if(reducePageTable.contains(key))
							{	
								//System.out.println("Reducing key : "+key);
								pageTable.put(key, pageTable.get(key) - 1);
							}
						}
						pageTable.put(page, currentBufferSize);
						
					/*	System.out.println("C Updated Buffers : "+buffers);
						System.out.println("C Updated Page Table : "+pageTable);
						System.out.println("C Updated Page Table keys : "+pageTable.keySet());
					*/
					}
				}
				else
				{
				/*	System.out.println("Page Table doesnt have pg");
				*/
					pageFaults++;
					
					int currentBufferSize = buffers.size();
					if(currentBufferSize<sizeBuffer)
					{
						buffers.add(currentBufferSize, page);
						pageTable.put(page, currentBufferSize);
					}
					else
					{
						int pageToRemove = buffers.get(0);
						buffers.remove(0);
						pageTable.remove(pageToRemove);
						for (Integer key : pageTable.keySet()) {
							pageTable.put(key, pageTable.get(key) - 1);
						}
						currentBufferSize = buffers.size();
						buffers.add(currentBufferSize, page);
						pageTable.put(page, currentBufferSize);
					}
				/*	System.out.println("Updated Buffers : "+buffers);
					System.out.println("Updated Page Table : "+pageTable);
					System.out.println("Updated Page Table keys : "+pageTable.keySet());
				*/	
				}
			}
			
			buffers = new ArrayList<Integer>();
			pageTable = new HashMap<Integer, Integer>();
			
			System.out.println("\nQ3 : Page Faults : "+pageFaults);
		
			
			
			
			
			
			
			
			
			
			
			
			
			pageFaults = 0;
			counter = 0;
			scanner = new Scanner(new File("referenceString4.txt"));
			while(scanner.hasNextInt())
			{
				
				counter++;
				int page = scanner.nextInt();
				//System.out.println("Page to Insert : "+page);
				
				if(pageTable.containsKey(page))
				{
					
	/*				System.out.println("C Buffers : "+buffers);
					System.out.println("C Page Table : "+pageTable);
					System.out.println("C Page Table keys : "+pageTable.keySet());
	*/				
					
					if(buffers.indexOf(page)==buffers.size()-1)
					{
						//System.out.println("Do noin..");	
					}
					else
					{
						ArrayList<Integer> reducePageTable = new ArrayList<>();
						for(int x = 0; x < buffers.size(); x++)
						{
							if(buffers.indexOf(page)<x)
								reducePageTable.add(buffers.get(x));
						}
						
						buffers.remove(new Integer(page));
						int currentBufferSize = buffers.size();
						buffers.add(currentBufferSize, page);
						for (Integer key : pageTable.keySet()) 
						{
							if(reducePageTable.contains(key))
							{	
								//System.out.println("Reducing key : "+key);
								pageTable.put(key, pageTable.get(key) - 1);
							}
						}
						pageTable.put(page, currentBufferSize);
						
					/*	System.out.println("C Updated Buffers : "+buffers);
						System.out.println("C Updated Page Table : "+pageTable);
						System.out.println("C Updated Page Table keys : "+pageTable.keySet());
					*/
					}
				}
				else
				{
				/*	System.out.println("Page Table doesnt have pg");
				*/
					pageFaults++;
					
					int currentBufferSize = buffers.size();
					if(currentBufferSize<sizeBuffer)
					{
						buffers.add(currentBufferSize, page);
						pageTable.put(page, currentBufferSize);
					}
					else
					{
						int pageToRemove = buffers.get(0);
						buffers.remove(0);
						pageTable.remove(pageToRemove);
						for (Integer key : pageTable.keySet()) {
							pageTable.put(key, pageTable.get(key) - 1);
						}
						currentBufferSize = buffers.size();
						buffers.add(currentBufferSize, page);
						pageTable.put(page, currentBufferSize);
					}
				/*	System.out.println("Updated Buffers : "+buffers);
					System.out.println("Updated Page Table : "+pageTable);
					System.out.println("Updated Page Table keys : "+pageTable.keySet());
				*/	
				}
			}
			
			buffers = new ArrayList<Integer>();
			pageTable = new HashMap<Integer, Integer>();
			
			System.out.println("\nQ4 : Page Faults : "+pageFaults);
			
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}